package com.example.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.entity.Product;
import com.example.product.service.ProductService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/products")
@Slf4j
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping
	public Product saveProduct(@RequestBody Product prd) {
		System.out.println("ProductController saveProduct");
		return productService.saveProduct(prd);
	}

	@GetMapping("/{id}")
	public Optional<Product> findProductByNameWithCurr(
			@RequestParam(value = "currency", required = false, defaultValue = "USD") String currency,
			@PathVariable("id") Long id) {
		System.out.println("ProductController findProductByName");
		System.out.println("currency = " + currency);
		Optional<Product> prod = productService.findProductById(id);
		Double exchangeValue = productService.getExchangeRate(currency);
		return productService.getProductInCurrency(prod, exchangeValue);
	}

	@GetMapping
	public List<Product> getAllProducts() {
		System.out.println("ProductController getAllProducts");
		List<Product> products = productService.getAllProducts();
		return productService.incrementViewCountForProducts(products);
	}

	@GetMapping("/most-viewed")
	public List<Product> getMostViewedProducts(
			@RequestParam(value = "size", required = false, defaultValue = "5") int size,
			@RequestParam(value = "currency", required = false, defaultValue = "USD") String currency) {
		System.out.println("ProductController getMostViewedProducts");
		System.out.println("currency = " + currency);

		List<Product> products = productService.filterProductsByViewCountAndSize(size);
		products = productService.incrementViewCountForProducts(products);
		return productService.getProductsInCurrency(products, currency);
	}

	@DeleteMapping("/{id}")
	public Optional<Product> deleteProduct(@PathVariable("id") Long id) {
		System.out.println("ProductController deleteProduct");
		return productService.deleteProductById(id);
	}

}

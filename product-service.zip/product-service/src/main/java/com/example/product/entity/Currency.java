package com.example.product.entity;

public enum Currency {
	
	USD, CAD, EUR, GBP;

}

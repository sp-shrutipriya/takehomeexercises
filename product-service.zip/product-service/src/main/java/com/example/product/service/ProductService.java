package com.example.product.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.product.entity.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	public Product saveProduct(Product product) {
		System.out.println("ProductService saveProduct");
		return productRepository.save(product);
	}

	public Optional<Product> findProductById(Long id) {
		System.out.println("ProductService findProductById");
		Optional<Product> prod = productRepository.findById(id);
		if (prod.isPresent() && prod.get().isVisible()) {
			incrementViewCount(prod.get());
			return productRepository.findById(id);
		}

		return null;
	}

	public Optional<Product> deleteProductById(Long id) {
		System.out.println("ProductService deleteProductById");
		Optional<Product> prod = productRepository.findById(id);
		prod.get().setVisible(false);
		productRepository.save(prod.get());
		return productRepository.findById(id);
	}

	public List<Product> getAllProducts() {
		System.out.println("ProductService getAllProducts");
		return productRepository.findAllByVisible(true);
	}

	public List<Product> incrementViewCountForProducts(List<Product> products) {
		System.out.println("ProductService incrementViewCountForProducts");
		for (Product p : products) {
			incrementViewCount(p);
		}
		return products;
	}

	public List<Product> getProductsInCurrency(List<Product> products, String currency) {
		System.out.println("ProductService getProductsInCurrency");
		Double exchangeValue = getExchangeRate(currency);
		for (Product p : products) {
			getProductInCurrency(Optional.of(p), exchangeValue);
		}
		return products;
	}

	private void incrementViewCount(Product prod) {
		System.out.println("ProductService incrementViewCount");
		prod.setViewCount(prod.getViewCount() + 1);
		productRepository.save(prod);
	}

	public List<Product> findAllProductsPaginated(int size) {
		System.out.println("ProductService findAllProductsPaginated");
		Sort sort = Sort.by("viewCount").descending();
		Pageable pageable = PageRequest.of(0, size, sort);
		return productRepository.findAllByVisible(true, pageable);
	}

	public List<Product> filterProductsByViewCountAndSize(int size) {
		System.out.println("ProductService filterProductsByViewCountAndSize");
		List<Product> returnList = new ArrayList<>();
		List<Product> products = findAllProductsPaginated(size);
		for (Product p : products) {
			if (p.getViewCount() >= 1) {
				returnList.add(p);

			}
		}
		return returnList;
	}

	public double getExchangeRate(String currency) {

		System.out.println("ProductService getExchangeRate");
		Double exchangeValue = null;

		if ("USD".equals(currency)) {
			exchangeValue = 1D;
		} else {

			String url = "http://api.currencylayer.com/live?access_key=57b26d26dee9328c1693662e4ec7d1b5&currencies=USD,CAD,EUR,GBP&format=1";
			URL obj;
			StringBuffer response = new StringBuffer();
			try {

				obj = new URL(url);
				HttpURLConnection con = (HttpURLConnection) obj.openConnection();
				con.setRequestMethod("GET");
				con.setRequestProperty("User-Agent", "Mozilla/5.0");
				int responseCode = con.getResponseCode();
				System.out.println("\nSending 'GET' request to URL : " + url);
				System.out.println("Response Code : " + responseCode);
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}

				in.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

			Object ob = JSONValue.parse(response.toString());

			if (ob instanceof JSONObject) {

				JSONObject jsonObject = (JSONObject) ob;
				JSONObject quotes = (JSONObject) jsonObject.get("quotes");
				if ("CAD".equals(currency)) {
					exchangeValue = (Double) quotes.get("USDCAD");
				} else if ("EUR".equals(currency)) {
					exchangeValue = (Double) quotes.get("USDEUR");
				} else if ("GBP".equals(currency)) {
					exchangeValue = (Double) quotes.get("USDGBP");
				} else {
					exchangeValue = 1D;
				}
			}
		}

		return exchangeValue;
	}

	public Optional<Product> getProductInCurrency(Optional<Product> prod, Double exchangeValue) {
		System.out.println("ProductService getProductInCurrency");
		Product product = prod.isPresent() ? prod.get() : null;
		product.setPrice(product.getPrice() * exchangeValue);
		return Optional.of(product);
	}

}
